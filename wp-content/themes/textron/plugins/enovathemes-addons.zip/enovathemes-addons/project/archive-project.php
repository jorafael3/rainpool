<?php
	get_header();
		do_action('textron_enovathemes_title_section');
		include(ENOVATHEMES_ADDONS.'project/content-project-loop.php');
	get_footer(); 
?>